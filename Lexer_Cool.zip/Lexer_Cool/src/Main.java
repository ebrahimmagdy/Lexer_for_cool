public class Main {
    public static void main(String[] args){
        String file = "good.cl";
        if(args.length >= 1)
            file = args[0];
        Excution ex = new Excution(file);
        ex.writeTokens(file + "-lex");
    }
}